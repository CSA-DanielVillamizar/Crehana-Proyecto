Configuration Main
{

Param ( [string] $nodeName, [string] $webDeployPackage )

Import-DscResource -ModuleName PSDesiredStateConfiguration

Node $nodeName
  {
   		# Install the IIS role 
		WindowsFeature IIS 
		{ 
			Ensure          = "Present" 
			Name            = "Web-Server" 
		} 
		# Install the Web Management Service
		WindowsFeature WebManagementService 
		{
            Name   = "Web-Mgmt-Service"
            Ensure = "Present"
        }
		# Install the ASP .NET 4.5 role 
		WindowsFeature AspNet45 
		{ 
			Ensure          = "Present" 
			Name            = "Web-Asp-Net45" 
		}
        # Install the Web Management Console
         WindowsFeature WebManagementConsole
        {
            Name = "Web-Mgmt-Console"
            Ensure = "Present"
        }
		  WindowsFeature HTTPRedirection
        {
          Name = "Web-Http-Redirect"
          Ensure = "Present"
        }
        WindowsFeature CustomLogging
        {
          Name = "Web-Custom-Logging"
          Ensure = "Present"
        }
        WindowsFeature LogginTools
        {
          Name = "Web-Log-Libraries"
          Ensure = "Present"
        }
        WindowsFeature RequestMonitor
        {
          Name = "Web-Request-Monitor"
          Ensure = "Present"
        }
        WindowsFeature Tracing
        {
          Name = "Web-Http-Tracing"
          Ensure = "Present"
        }
        WindowsFeature BasicAuthentication
        {
          Name = "Web-Basic-Auth"
          Ensure = "Present"
        }
        WindowsFeature WindowsAuthentication
        {
          Name = "Web-Windows-Auth"
          Ensure = "Present"
        }
        WindowsFeature ApplicationInitialization
        {
          Name = "Web-AppInit"
          Ensure = "Present"
        }
	   
		    Script DeployWebPackage
		{
			GetScript = {@{Result = "DeployWebPackage"}}
			TestScript = {$false}
			SetScript ={
				[system.io.directory]::CreateDirectory("C:\WebApp")
				$dest = "C:\WebApp\Site.zip" 
				Remove-Item -path "C:\inetpub\wwwroot" -Force -Recurse -ErrorAction SilentlyContinue
				Invoke-WebRequest $using:webDeployPackage -OutFile $dest
				Add-Type -assembly "system.io.compression.filesystem"
				[io.compression.zipfile]::ExtractToDirectory($dest, "C:\inetpub\wwwroot")
			}
			DependsOn  = "[WindowsFeature]IIS"
		}

		# Copy the website content 
		File WebContent 
		{ 
			Ensure          = "Present" 
			SourcePath      = "C:\WebApp"
			DestinationPath = "C:\Inetpub\wwwroot"
			Recurse         = $true 
			Type            = "Directory" 
			DependsOn       = "[Script]DeployWebPackage" 
		}    
	
  }
}